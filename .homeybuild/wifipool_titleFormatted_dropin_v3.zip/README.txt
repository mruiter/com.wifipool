Drop-in patch v3 (fix missing 'title' on action)
-----------------------------------------------
This replaces ONLY the action card file with both `title` and `titleFormatted`.

Install:
- Extract into your app root, so it overwrites:
  .homeycompose/flow/actions/set_poll_interval.json

Then run:
  homey app validate
