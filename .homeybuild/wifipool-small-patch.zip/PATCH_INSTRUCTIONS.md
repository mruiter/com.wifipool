
# WiFiPool Patch – Add `measure_temperature` capability + migrate existing devices

This patch does two things:
1. Adds the `measure_temperature` capability to the driver (affects **newly paired** devices).
2. Provides a tiny code snippet to **auto-add** the capability to **already paired** devices on init.

---

## 1) Replace `drivers/wifipool/driver.compose.json`
Use the file in this zip at:
```
drivers/wifipool/driver.compose.json
```

Then restart the app. Newly paired devices will now include `measure_temperature`.

---

## 2) Edit `drivers/wifipool/device.js` (migrate existing devices)
Add the helper *inside your device class* and call it in `onInit()` **before** you set any capability values or start polling.

### A) Add this helper method inside the class
```js
async _ensureCapabilities(ids) {
  for (const id of ids) {
    if (!this.hasCapability(id)) {
      try {
        await this.addCapability(id);
        this.log(`[WiFiPool][Device] added capability: ${id}`);
      } catch (e) {
        this.error(`[WiFiPool][Device] failed to add ${id}:`, e);
      }
    }
  }
}
```

### B) Call it at the top of `onInit()`
```js
await this._ensureCapabilities([
  'measure_temperature',
  'measure_redox',
  'measure_ph',
  'measure_flow',
  'alarm_health'
]);
```

> Tip: After patching, restart the app. You can keep your existing device — the snippet will add the new capability on next init. Alternatively, you can re-pair the device to get the updated set of capabilities from the start.
