Compose migration drop-in
-------------------------
This moves all Flow cards (actions, conditions, triggers) into .homeycompose
and empties flow.* arrays in app.json to avoid duplicate IDs.

Steps:
1) Extract this zip into your project root.
   - It will create/overwrite files under .homeycompose/flow/...
   - It will replace app.json with a version where flow.actions/conditions/triggers are empty.

2) Validate:
   homey app validate

Notes:
- titleFormatted added for: set_poll_interval, refresh_now, and all conditions.
- We preserved your trigger tokens and args as-is.
