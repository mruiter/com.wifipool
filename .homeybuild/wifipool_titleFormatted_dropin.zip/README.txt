Drop-in patch for Homey Compose `titleFormatted` warnings
========================================================

Copy the `.homeycompose` folder from this zip into the **root of your Homey app**.
It will create/overwrite the following files:

- .homeycompose/flow/actions/set_poll_interval.json
- .homeycompose/flow/conditions/flow_above.json
- .homeycompose/flow/conditions/flow_below.json
- .homeycompose/flow/conditions/ph_above.json
- .homeycompose/flow/conditions/ph_below.json
- .homeycompose/flow/conditions/redox_above.json
- .homeycompose/flow/conditions/redox_below.json

Then run:
  homey app validate
or
  homey app run

This removes the "titleFormatted is missing" warnings.
