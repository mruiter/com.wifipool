# WiFiPool – Patch bundle (persisted Auto-Setup + device polling + settings preview)

This zip contains **drop‑in** files to extend your current *working* discovery:
- Persist the discovered `domain`, `device_uuid` & `io_map` to Settings
- Show a live **Discovered config** preview on the settings page
- Start a device **poller** that updates capabilities (`measure_ph`, `measure_redox`, `measure_flow`, optional `measure_temperature`) and toggles `alarm_health` on errors

## Files in this bundle

- `settings/index.html` → replaces your current settings page
- `drivers/wifipool/device.js` → replaces your device class (SDK3, ESM)
- `patches/api-autosetup-persist.diff` → a tiny patch to apply inside your existing `api.js` Auto-Setup handler

> We intentionally do **not** ship your `api.js` to avoid overwriting your already working discovery logic. Just add the 4 `settings.set(...)` lines and return the JSON as shown in the patch.

## How to apply

1) **Replace** files:
   - Copy `settings/index.html` into your app at `./settings/index.html`
   - Copy `drivers/wifipool/device.js` into `./drivers/wifipool/device.js`

2) **Patch your `api.js`**:
   - Open your `api.js`
   - Find the Auto-Setup endpoint handler (the code that logs in, calls `/groups/accessible`, `/groups/getInfo`, probes `/harmopool/getStats` and figures out the IO strings)
   - After you have `domainId`, `deviceUuid`, and `ioMap`:
     ```js
     homey.settings.set('domain', domainId);
     homey.settings.set('device_uuid', deviceUuid);
     homey.settings.set('io_map', ioMap);
     homey.settings.set('discovered_at', new Date().toISOString());
     return { ok:true, domain: domainId, device_uuid: deviceUuid, io_map: ioMap };
     ```
   - Save.

3) **Ensure your `app.json` API routes** match the buttons used by the settings page:
   - The settings UI calls:
     - `POST /api/app/<appId>/test`       → maps to a function like `export default { test(req) { ... } }`
     - `POST /api/app/<appId>/discover`   → maps to `discover(req)`
     - `POST /api/app/<appId>/autosetup`  → maps to `autosetup(req)`
   - Your `app.json` must have an `api` section that defines those routes, e.g.:
     ```json
     "api": {
       "test":      { "description": "Test API",       "method": "POST" },
       "discover":  { "description": "Discover IOs",   "method": "POST" },
       "autosetup": { "description": "Auto Setup",     "method": "POST" }
     }
     ```

4) **Capabilities**:
   - Make sure your device (driver) has the capabilities you want to update, for example:
     ```json
     "capabilities": [
       "alarm_health",
       "measure_ph",
       "measure_redox",
       "measure_flow"
       // "measure_temperature" // optional, if you add it
     ]
     ```

5) **Run**
   ```bash
   npm install
   homey app run
   ```
   - Open Settings → save email/password (domain can remain blank; Auto Setup will fill it)
   - Click **Auto Setup** → the preview should fill
   - Add the device (if not already) → watch console updates every 60s (configurable)

## Notes
- The poller reads `io_map` from Settings:
  - `io_map.ph`     → last `analog` value becomes `measure_ph`
  - `io_map.redox`  → last `analog` value becomes `measure_redox`
  - `io_map.flow`   → last `analog` value becomes `measure_flow` (if present)
  - `io_map.temperature` → last `ds18b20` temperature becomes `measure_temperature` (if capability exists)
- If your `WiFiPoolClient` lacks `ensureLogin(email, password)`, the device falls back to `login(email, password)`.
- Flow cards (`ph_updated`, `redox_updated`, `flow_updated`) are triggered when values change, if defined.

Good luck! 🚀
