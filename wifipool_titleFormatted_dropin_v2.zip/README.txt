Drop-in patch v2 for Homey Compose `titleFormatted`
---------------------------------------------------
Copy the `.homeycompose` folder from this zip into your app root.
This version removes the `[[device]]` placeholder to satisfy validation.

Files included:
- .homeycompose/flow/actions/set_poll_interval.json
- .homeycompose/flow/conditions/flow_above.json
- .homeycompose/flow/conditions/flow_below.json
- .homeycompose/flow/conditions/ph_above.json
- .homeycompose/flow/conditions/ph_below.json
- .homeycompose/flow/conditions/redox_above.json
- .homeycompose/flow/conditions/redox_below.json
